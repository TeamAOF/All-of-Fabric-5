from pathlib import Path
from os import walk
import os

name = input("block name: ")

